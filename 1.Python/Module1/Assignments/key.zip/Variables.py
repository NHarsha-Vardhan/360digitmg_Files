# Variables

##### 1. What will be the output of the following (can/cannot):
#Age1=5
#5age=55


#### a. Age1 = 5
Age1 = 5 # Valid, Age1 can be a variable which is assigned with value 5

#### b. 5age = 55
5age = 55 # Invalid, variable cannot start with a number

##### 2. What will be the output of following (can/cannot):
    Age_1=100
    age@1=100 

#### a. Age_1 = 100
Age_1 = 100 #Valid, we can assign 100 to the variable Age_1

#### b. age@1 = 100
age@1 = 100 #Invalid, because special character apart from '_' cannot be used in a variable name

##### 3. How can you delete variables in Python ? 

# We can delete variable in Python by using del function
a = 100

del(a)

a


