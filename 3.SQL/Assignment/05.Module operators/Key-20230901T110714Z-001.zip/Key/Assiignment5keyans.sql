# Q1. Create a Supermart_DB with the tables created from the datasets shared (Customer.csv, Sales.csv and Product.csv files) 

# Sol: 
#Create a new database in your database management system, and name it Supermart_DB.
Create database Supermart_DB;


#Create a new table called "customers" in the Supermart_DB database 
Use Supermart_DB;

CREATE TABLE customers (
  customer_id varchar(50) PRIMARY KEY,
  customer_name CHAR(50),
  segment CHAR(50),
  Age int,
  Country CHAR(100),
  City char(50),
  state CHAR(20),
  Postal_code Char(50),
  Region Char(20)
);
#Load the data from the Customer.csv file into the customers table 

SHOW GLOBAL VARIABLES LIKE 'local_infile';
SET GLOBAL local_infile=1;
grant file on *.* to 'root'@'localhost';

SHOW VARIABLES LIKE "secure_file_priv";

LOAD DATA INFILE 'F:/360_content/SQL/Datasets/Customer.csv'
INTO TABLE customers
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

#Create a new table called "products" in the Supermart_DB database 

CREATE TABLE products (
  product_id varchar(255) PRIMARY KEY,
  category VARCHAR(255),
  sub_category varchar(255),
  product_name VARCHAR(255)
);

#Load the data from the Product.csv file into the products table 

LOAD DATA INFILE 'F:/360_content/SQL/Datasets/Product.csv'
INTO TABLE products
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

#Create a new table called "sales" in the Supermart_DB database
									
CREATE TABLE sales (
  Order_Line INT primary key,
  Order_ID varchar(255),
  Order_Date varchar(255),
  ShipDate varchar(255),
  ShipMode char(255),
  Customer_ID varchar(255),
  Product_ID varchar(255),
  Sales decimal(10,2),
  Quantity int,
  Discount decimal(10,2),
  Profit decimal(10,2),
  FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
  FOREIGN KEY (product_id) REFERENCES products(product_id)
);

describe sales;
#Load the data from the Sales.csv file into the sales table 

LOAD DATA INFILE 'F:/360_content/SQL/Datasets/Sales.csv'
INTO TABLE sales
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

show tables;
select * from sales;

#Q2 Define the relationship between the tables using constraints/keys.

ALTER TABLE sales
ADD CONSTRAINT fk_sales_customer_id
FOREIGN KEY (customer_id)
REFERENCES customers(customer_id);

ALTER TABLE sales
ADD CONSTRAINT fk_sales_product_id
FOREIGN KEY (product_id)
REFERENCES products(product_id);

#Q3In the database Supermart _DB, find the following:

#A. Get the list of all the cities where the region is north or east without any duplicates using IN statement.

SELECT DISTINCT city
FROM customers
WHERE region IN ('North', 'East');

#B. Get the list of all orders where the ‘sales’ value is between 100 and 500 using the BETWEEN operator.
select*from customers;

SELECT *
FROM sales
WHERE sales BETWEEN 100 AND 500;

#C. Get the list of customers whose last name contains only 4 characters using LIKE.

SELECT *FROM customers
WHERE customer_name LIKE '% ____';

#SELECTION COMMANDS:- ordering
#1Retrieve all orders where the ‘discount’ value is greater than zero ordered in descending order basis ‘discount’ value

SELECT *
FROM sales
WHERE Discount > 0
ORDER BY Discount DESC;

#2 Limit the number of results in the above query to the top 10.
SELECT *
FROM sales
WHERE Discount > 0
ORDER BY Discount DESC
LIMIT 10;

#Aggregate commands:-
#1 Find the sum of all ‘sales’ values.

SELECT SUM(sales) AS total_sales
FROM sales;

#2 Find count of the number of customers in the north region with ages between 20 and 30
SELECT COUNT(*) AS num_customers
FROM customers
WHERE region = 'North' AND age BETWEEN 20 AND 30;

#3 Find the average age of east region customers

SELECT AVG(age) AS avg_age
FROM customers
WHERE region = 'East';

#4 Find the minimum and maximum aged customers from Philadelphia
SELECT MIN(age) AS min_age, MAX(age) AS max_age
FROM customers
WHERE city = 'Philadelphia';

#GROUP BY COMMANDS:-
#1 Create a display with the information below for each product ID.
#Total sales (in $) order by this column in descending 
#Total sales quantity
#The number of orders
#Max Sales value
#Min Sales value
#Average sales value
select*from products;
select*from sales;
SELECT 
    product_id AS 'Product_id', 
    SUM(quantity * sales) AS 'Total Sales ($)', 
    SUM(quantity) AS 'Total Sales Quantity', 
    COUNT(DISTINCT order_id) AS 'Number of Orders', 
    MAX(sales) AS 'Max Sales Value', 
    MIN(sales) AS 'Min Sales Value', 
    AVG(sales) AS 'Average Sales Value'
FROM 
    sales 
GROUP BY 
    product_id 
ORDER BY 
    'Total Sales ($)' DESC;

#2 Get the list of product ID’s where the quantity of product sold is greater than 10
SELECT product_id
FROM sales
GROUP BY product_id
HAVING SUM(quantity) > 10;