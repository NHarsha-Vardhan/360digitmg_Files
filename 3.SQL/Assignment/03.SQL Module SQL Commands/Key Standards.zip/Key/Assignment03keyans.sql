#DATABASE CREATE:-
#1.	Create a database ‘classroom

Create database classroom;

#2.	Create a table named ‘science_class’ with the following properties
#     3 columns(enrollment_no int, name char, science_marks int)

use classroom;
Create table science_class(
Enrollment_no int,
name char(30),
science_marks int);

#INSERTING &IMPORTING:-
#1.	Insert the following data into science_class using insert into command

Insert into science_class(Enrollment_no,name,science_marks)
values(1,'popeye',33),(2,'olive',54),(3,'brutus',98);

#2.	import data from CSV file ‘student.csv’ attached in resources to science_class to insert data of next 8 students

show variables like 'secure_file_priv';

LOAD DATA INFILE 'E:/Downloads/Students.csv'
INTO TABLE science_class 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"' 
LINES TERMINATED BY '\n' 
IGNORE 1 ROWS;


#SELECT & WHERE:-
#1.	Retrieve all data from the table ‘Science_Class’

select * from science_class;


#2.	Retrieve the name of students who have scored more than 60 marks

SELECT Name FROM science_class WHERE Science_Marks = 60;

#3.	Retrieve all data of students who have scored more than 35 but less than 60 marks

SELECT * FROM science_class WHERE Science_Marks > 35 AND Science_Marks < 60;

#4.	Retrieve all other students i.e. who have scored less than or equal to 45 or more than or equal to 60.

select name from science_class
where science_marks<=45 and science_marks>=60;

#UPDATING TABLES:-
#1.	update the marks of popeye to 45

update science_class
set science_marks=45
where name='popeye';

select * from science_class;

#2.	delete the row containing details of the student named ‘robb’

delete from science_class
where name='Robb';

#3.	Rename column ‘name’ to ‘student_name’
ALTER TABLE science_class CHANGE COLUMN name student_name CHAR(50);
select * from science_class;
