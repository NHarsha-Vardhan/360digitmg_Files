#DATABASE CREATE:-
#1.	Create a database ‘classroom’
Create database classroom;

#2.	Create a table named ‘science_class’ with the following properties
CREATE TABLE science_class (
  student_id SERIAL PRIMARY KEY,
  student_name VARCHAR(255) NOT NULL,
  biology_marks INTEGER,
  chemistry_marks INTEGER,
  physics_marks INTEGER
);

#3. Columns(enrollment_no int, name char, science_marks int)
CREATE TABLE students (
  enrollment_no INTEGER,
  name CHARACTER(255),
  science_marks INTEGER
);

#INSERTING &IMPORTING:-
#1.	Insert the following data into science_class using insert into command
INSERT INTO science_class (student_name, biology_marks, chemistry_marks, physics_marks)
VALUES
('John Doe', 85, 90, 92),
('Jane Smith', 90, 87, 93),
('Bob Johnson', 75, 82, 80),
('Alice Lee', 92, 93, 95),
('Tom Brown', 88, 89, 86);

#2.	import data from CSV file ‘student.csv’ attached in resources to science_class to insert data of next 8 students
COPY science_class (student_name, biology_marks, chemistry_marks, physics_marks)
FROM 'E:\Downloads\Student.csv' DELIMITER ',' CSV HEADER;
INTO TABLE science_class 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"' 
LINES TERMINATED BY '\n' 
IGNORE 1 ROWS;

SELECT * FROM science_class;

INSERT INTO science_class (id, first_name, last_name, age, gender, grade)
VALUES
(101, 'John', 'Doe', 16, 'M', 'A'),
(102, 'Jane', 'Doe', 15, 'F', 'B'),
(103, 'Bob', 'Smith', 17, 'M', 'A'),
(104, 'Sue', 'Johnson', 16, 'F', 'B'),
(105, 'Mike', 'Williams', 15, 'M', 'B'),
(106, 'Lisa', 'Garcia', 17, 'F', 'A'),
(107, 'David', 'Brown', 16, 'M', 'A'),
(108, 'Karen', 'Taylor', 15, 'F', 'B');

SELECT * FROM science_class;

#SELECT & WHERE:-
#1.	Retrieve all data from the table ‘Science_Class’
SELECT * FROM science_class;

#2. Retrieve the name of students who have scored more than 60 marks
SELECT name FROM science_class WHERE science_marks > 60;

#3. Retrieve all data of students who have scored more than 35 but less than 60 marks
SELECT * FROM science_class WHERE science_marks > 35 AND science_marks < 60;

#4. Retrieve all other students i.e. who have scored less than or equal to 45 or more than or equal to 60.
SELECT name FROM science_class WHERE science_marks <= 45 OR science_marks >= 60;

# Insert data into the 'science_class' table from the 'student' table
INSERT INTO science_class (enrollment_no, student_name, science_marks)
SELECT enrollment_no, first_name, science_marks FROM student;

#Retrieve all data from the 'abc' table
SELECT * FROM abc;

#Delete the 'student' table
DROP TABLE student;

#UPDATING TABLES:-
#1.	update the marks of popeye to 45
UPDATE science_class SET science_marks = 45 WHERE student_name = 'Popeye';

#2. Delete the row containing details of the student named 'Robb'
DELETE FROM science_class WHERE student_name = 'Robb';

#3. Rename the column 'name' to 'student_name'
ALTER TABLE science_class RENAME COLUMN name TO student_name;


